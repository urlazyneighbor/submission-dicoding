document.addEventListener("DOMContentLoaded", function() {
    showBooks();
});

function addBook() {
    const titleInput = document.getElementById("title");
    const authorInput = document.getElementById("author");
    const statusInput = document.getElementById("status");
    const yearInput = document.getElementById("year"); // Penambahan input tahun

    const title = titleInput.value;
    const author = authorInput.value;
    const status = statusInput.value;
    const year = yearInput.value; // Mengambil nilai tahun dari input

    if (title === "" || author === "" || year === "") { // Menambahkan pengecekan tahun
        alert("Judul, pengarang, dan tahun harus diisi!");
        return;
    }

    const book = { title, author, status, year }; // Menambahkan tahun ke dalam objek buku

    let books = [];
    if (localStorage.getItem("books")) {
        books = JSON.parse(localStorage.getItem("books"));
    }

    books.push(book);
    localStorage.setItem("books", JSON.stringify(books));

    // Reset input values
    titleInput.value = "";
    authorInput.value = "";
    yearInput.value = ""; // Mengosongkan input tahun

    showBooks();
}

function showBooks() {
    const belumDibacaContainer = document.getElementById("belumDibaca");
    const sudahDibacaContainer = document.getElementById("sudahDibaca");

    belumDibacaContainer.innerHTML = "";
    sudahDibacaContainer.innerHTML = "";

    let books = [];
    if (localStorage.getItem("books")) {
        books = JSON.parse(localStorage.getItem("books"));
    }

    books.forEach(book => {
        const li = document.createElement("li");
        li.textContent = `${book.title} - ${book.author} (${book.year})`; // Menampilkan tahun buku

        if (book.status === "belumDibaca") {
            li.innerHTML += ` <button onclick="moveBook('${book.title}', 'sudahDibaca')">Selesai</button>`;
            belumDibacaContainer.appendChild(li);
        } else {
            li.innerHTML += ` <button onclick="moveBook('${book.title}', 'belumDibaca')">Kembali</button>`;
            li.innerHTML += ` <button onclick="deleteBook('${book.title}')">Hapus</button>`;
            sudahDibacaContainer.appendChild(li);
        }
    });
}

function moveBook(title, status) {
    let books = JSON.parse(localStorage.getItem("books"));
    const index = books.findIndex(book => book.title === title);

    if (index !== -1) {
        books[index].status = status;
        localStorage.setItem("books", JSON.stringify(books));
        showBooks();
    }
}

function deleteBook(title) {
    let books = JSON.parse(localStorage.getItem("books"));
    const index = books.findIndex(book => book.title === title);

    if (index !== -1) {
        books.splice(index, 1);
        localStorage.setItem("books", JSON.stringify(books));
        showBooks();
    }
}